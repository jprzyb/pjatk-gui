package s24512;

public enum StanZlecenia {
    PLANOWANE,NIEPLANOWANE,REALIZOWANE,ZAKONCZONE
}
