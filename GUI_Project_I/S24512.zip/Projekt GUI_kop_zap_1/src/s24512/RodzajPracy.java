package s24512;

public enum RodzajPracy {

    OGOLNA , MONTAZ , DEMONTAZ , WYMIANA

}
