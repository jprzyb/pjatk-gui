package logic_package;

public enum RodzajPracy {
    OGOLNA , MONTAZ , DEMONTAZ , WYMIANA
}
