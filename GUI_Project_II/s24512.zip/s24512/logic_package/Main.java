package logic_package;

import java.io.IOException;
import java.util.List;

public class Main {

    public static void main(String[] Args) throws IOException, ClassNotFoundException {

        // L E T S   F U N K I N   G O
        // H I   S Z Y M O N
//        Zlecenie zlecenie = new Zlecenie();
//        Listy.zlecenieList.add(zlecenie);
//        FileIO.savingZlecenie(Listy.zlecenieList, "zlecenie.bin");

//        Praca praca = new Praca();
//        Listy.pracaList.add(praca);
//        FileIO.savingPraca(Listy.pracaList , "praca.bin");

    }

}
