package grafic_package;

import javax.swing.*;

public class Menu {

    JMenuBar menu;
    JMenu dzialPracownikowMenu;



}
