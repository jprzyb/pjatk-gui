package logic_package;

public enum StanZlecenia {

    PLANOWANE , NIEPLANOWANE , REALIZOWANE , ZAKONCZONE

}
